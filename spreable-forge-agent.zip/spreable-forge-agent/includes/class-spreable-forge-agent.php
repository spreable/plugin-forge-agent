<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Spreable_Forge_Agent {

    const REST_NAMESPACE    = 'spreable-forge/v1';
    const OPTION_TOKEN      = 'spreable_forge_agent_token';
    const OPTION_LOG_MARKER = 'spreable_forge_last_log_marker';

    public function __construct() {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }

    /**
     * Executado na ativação pelo arquivo principal.
     */
    public static function on_activation() {
        if ( ! get_option( self::OPTION_TOKEN ) ) {
            $token = wp_generate_password( 64, false, false );
            add_option( self::OPTION_TOKEN, $token, false );
        }
    }

    public static function get_token() {
        $token = get_option( self::OPTION_TOKEN );
        if ( ! $token ) {
            $token = wp_generate_password( 64, false, false );
            update_option( self::OPTION_TOKEN, $token, false );
        }
        return $token;
    }

    public function register_routes() {

        // Info interna para admin (ver token, path etc).
        register_rest_route(
            self::REST_NAMESPACE,
            '/info',
            [
                'methods'             => 'GET',
                'callback'            => [ $this, 'route_info' ],
                'permission_callback' => function () {
                    return current_user_can( 'manage_options' );
                },
            ]
        );

        // Upload plugin gerado (zip em base64).
        register_rest_route(
            self::REST_NAMESPACE,
            '/upload-plugin',
            [
                'methods'             => 'POST',
                'callback'            => [ $this, 'route_upload_plugin' ],
                'permission_callback' => [ $this, 'check_auth' ],
                'args'                => [
                    'slug'       => [ 'required' => true ],
                    'zip_base64' => [ 'required' => true ],
                    'overwrite'  => [ 'required' => false ],
                ],
            ]
        );

        // Ativar plugin pelo slug.
        register_rest_route(
            self::REST_NAMESPACE,
            '/activate-plugin',
            [
                'methods'             => 'POST',
                'callback'            => [ $this, 'route_activate_plugin' ],
                'permission_callback' => [ $this, 'check_auth' ],
                'args'                => [
                    'slug' => [ 'required' => true ],
                ],
            ]
        );

        // Rodar testes básicos (lint + leitura de log).
        register_rest_route(
            self::REST_NAMESPACE,
            '/run-tests',
            [
                'methods'             => 'POST',
                'callback'            => [ $this, 'route_run_tests' ],
                'permission_callback' => [ $this, 'check_auth' ],
                'args'                => [
                    'slug' => [ 'required' => true ],
                ],
            ]
        );

        // Buscar logs (incremental).
        register_rest_route(
            self::REST_NAMESPACE,
            '/logs',
            [
                'methods'             => 'GET',
                'callback'            => [ $this, 'route_get_logs' ],
                'permission_callback' => [ $this, 'check_auth' ],
                'args'                => [
                    'since_last' => [ 'required' => false ],
                ],
            ]
        );
    }

    /**
     * Auth para chamadas do Forge:
     * Header: X-Forge-Token: <token>
     * ou Authorization: Bearer <token>
     */
    public function check_auth( WP_REST_Request $request ) {
        $header = $request->get_header( 'x-forge-token' );

        if ( ! $header ) {
            $auth = $request->get_header( 'authorization' );
            if ( $auth && stripos( $auth, 'bearer ' ) === 0 ) {
                $header = trim( substr( $auth, 7 ) );
            }
        }

        $token = self::get_token();

        if ( $header && hash_equals( $token, $header ) ) {
            return true;
        }

        return new WP_Error(
            'forbidden',
            'Unauthorized Spreable Forge request.',
            [ 'status' => 401 ]
        );
    }

    /**
     * GET /spreable-forge/v1/info
     * Somente admin logado.
     * Use isso UMA VEZ no template base para copiar o token e configurar no Forge.
     */
    public function route_info( WP_REST_Request $request ) {
        return [
            'token'       => self::get_token(),
            'debug_log'   => WP_CONTENT_DIR . '/debug.log',
            'plugin_dir'  => WP_PLUGIN_DIR,
            'site_url'    => site_url(),
            'wp_version'  => get_bloginfo( 'version' ),
            'php_version' => PHP_VERSION,
        ];
    }

    /**
     * POST /spreable-forge/v1/upload-plugin
     * body:
     * {
     *   "slug": "meu-plugin",
     *   "zip_base64": "...",
     *   "overwrite": true
     * }
     */
    public function route_upload_plugin( WP_REST_Request $request ) {
        $slug       = sanitize_key( $request->get_param( 'slug' ) );
        $zip_base64 = $request->get_param( 'zip_base64' );
        $overwrite  = (bool) $request->get_param( 'overwrite' );

        if ( ! $slug || ! $zip_base64 ) {
            return new WP_Error( 'invalid_params', 'Missing slug or zip_base64.', [ 'status' => 400 ] );
        }

        if ( ! function_exists( 'WP_Filesystem' ) ) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }
        if ( ! function_exists( 'unzip_file' ) ) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }

        global $wp_filesystem;
        WP_Filesystem();

        $plugins_dir = WP_PLUGIN_DIR;
        $plugin_dir  = trailingslashit( $plugins_dir ) . $slug;

        // Remove plugin anterior se overwrite = true.
        if ( $overwrite && is_dir( $plugin_dir ) ) {
            $this->rrmdir( $plugin_dir );
        }

        // Decodifica ZIP.
        $zip_data = base64_decode( $zip_base64 );
        if ( ! $zip_data ) {
            return new WP_Error( 'invalid_zip', 'Could not decode zip_base64.', [ 'status' => 400 ] );
        }

        $tmp_file = wp_tempnam( 'spreable-forge-' . $slug );
        if ( ! $tmp_file ) {
            return new WP_Error( 'temp_error', 'Could not create temp file.', [ 'status' => 500 ] );
        }

        file_put_contents( $tmp_file, $zip_data );

        $result = unzip_file( $tmp_file, $plugins_dir );
        @unlink( $tmp_file );

        if ( is_wp_error( $result ) ) {
            return new WP_Error(
                'unzip_error',
                'Error extracting plugin zip: ' . $result->get_error_message(),
                [ 'status' => 500 ]
            );
        }

        if ( ! is_dir( $plugin_dir ) ) {
            return new WP_Error(
                'missing_plugin_dir',
                'Plugin directory not found after extraction: ' . $plugin_dir,
                [ 'status' => 500 ]
            );
        }

        return [
            'success'     => true,
            'message'     => 'Plugin uploaded and extracted.',
            'plugin_path' => $plugin_dir,
        ];
    }

    /**
     * POST /spreable-forge/v1/activate-plugin
     * body: { "slug": "meu-plugin" }
     */
    public function route_activate_plugin( WP_REST_Request $request ) {
        $slug = sanitize_key( $request->get_param( 'slug' ) );
        if ( ! $slug ) {
            return new WP_Error( 'invalid_params', 'Missing slug.', [ 'status' => 400 ] );
        }

        if ( ! function_exists( 'activate_plugin' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $plugin_file = $this->find_plugin_main_file( $slug );
        if ( ! $plugin_file ) {
            return new WP_Error(
                'main_file_not_found',
                'Could not find main plugin file for slug ' . $slug,
                [ 'status' => 500 ]
            );
        }

        $result = activate_plugin( $plugin_file );

        if ( is_wp_error( $result ) ) {
            return [
                'success' => false,
                'error'   => $result->get_error_message(),
                'file'    => $plugin_file,
            ];
        }

        $active = (array) get_option( 'active_plugins', [] );
        if ( in_array( $plugin_file, $active, true ) ) {
            return [
                'success'     => true,
                'message'     => 'Plugin activated.',
                'plugin_file' => $plugin_file,
            ];
        }

        return [
            'success'     => false,
            'message'     => 'Activation returned no error but plugin not active.',
            'plugin_file' => $plugin_file,
        ];
    }

    /**
     * POST /spreable-forge/v1/run-tests
     * body: { "slug": "meu-plugin" }
     * - Lint (quando possível)
     * - Leitura de logs recentes
     */
    public function route_run_tests( WP_REST_Request $request ) {
        $slug = sanitize_key( $request->get_param( 'slug' ) );
        if ( ! $slug ) {
            return new WP_Error( 'invalid_params', 'Missing slug.', [ 'status' => 400 ] );
        }

        $plugin_dir = trailingslashit( WP_PLUGIN_DIR ) . $slug;
        if ( ! is_dir( $plugin_dir ) ) {
            return new WP_Error(
                'missing_plugin_dir',
                'Plugin directory not found for slug ' . $slug,
                [ 'status' => 404 ]
            );
        }

        $lint_results = $this->lint_php_files( $plugin_dir );
        $logs         = $this->get_recent_debug_log();

        $has_fatal    = false;
        $log_snippets = [];

        foreach ( $logs as $line ) {
            $lower = strtolower( $line );
            if (
                strpos( $lower, 'fatal error' ) !== false ||
                strpos( $lower, 'parse error' ) !== false
            ) {
                $has_fatal = true;
            }

            if ( strpos( $lower, $slug ) !== false ) {
                $log_snippets[] = $line;
            }
        }

        $passed = empty( $lint_results['errors'] ) && ! $has_fatal;

        return [
            'success'       => true,
            'passed'        => $passed,
            'php_lint'      => $lint_results,
            'log_has_fatal' => $has_fatal,
            'log_snippets'  => $log_snippets,
        ];
    }

    /**
     * GET /spreable-forge/v1/logs?since_last=1
     * Retorna trecho incremental do debug.log.
     */
    public function route_get_logs( WP_REST_Request $request ) {
        $since_last = (int) $request->get_param( 'since_last' ) === 1;
        $logs       = $this->get_recent_debug_log( $since_last );

        return [
            'success' => true,
            'lines'   => $logs,
        ];
    }

    private function rrmdir( $dir ) {
        if ( is_file( $dir ) || is_link( $dir ) ) {
            @unlink( $dir );
            return;
        }

        if ( ! is_dir( $dir ) ) {
            return;
        }

        $items = scandir( $dir );
        foreach ( $items as $item ) {
            if ( $item === '.' || $item === '..' ) {
                continue;
            }

            $path = $dir . DIRECTORY_SEPARATOR . $item;

            if ( is_dir( $path ) ) {
                $this->rrmdir( $path );
            } else {
                @unlink( $path );
            }
        }

        @rmdir( $dir );
    }

    private function find_plugin_main_file( $slug ) {
        $base_dir = trailingslashit( WP_PLUGIN_DIR ) . $slug;
        if ( ! is_dir( $base_dir ) ) {
            return false;
        }

        // 1) Tenta slug/slug.php direto.
        $candidate = $slug . '/' . $slug . '.php';
        if ( file_exists( WP_PLUGIN_DIR . '/' . $candidate ) ) {
            return $candidate;
        }

        // 2) Procura arquivo com header de plugin.
        if ( ! function_exists( 'get_file_data' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator( $base_dir, RecursiveDirectoryIterator::SKIP_DOTS )
        );

        foreach ( $iterator as $file ) {
            if ( $file->getExtension() !== 'php' ) {
                continue;
            }

            $rel_path = str_replace( WP_PLUGIN_DIR . '/', '', $file->getPathname() );

            $data = get_file_data(
                $file->getPathname(),
                [
                    'Name' => 'Plugin Name',
                ],
                'plugin'
            );

            if ( ! empty( $data['Name'] ) ) {
                return $rel_path;
            }
        }

        return false;
    }

    private function lint_php_files( $dir ) {
        $errors  = [];
        $checked = 0;

        $php_path = '';
        if ( function_exists( 'shell_exec' ) ) {
            $php_path = trim( (string) shell_exec( 'which php' ) );
        }

        if ( ! $php_path ) {
            return [
                'checked' => 0,
                'errors'  => [],
                'note'    => 'PHP CLI not available; skipping php -l lint.',
            ];
        }

        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator( $dir, RecursiveDirectoryIterator::SKIP_DOTS )
        );

        foreach ( $iterator as $file ) {
            if ( $file->getExtension() !== 'php' ) {
                continue;
            }

            $checked++;
            $cmd    = escapeshellcmd( $php_path ) . ' -l ' . escapeshellarg( $file->getPathname() ) . ' 2>&1';
            $output = shell_exec( $cmd );

            if ( $output && stripos( $output, 'No syntax errors detected' ) === false ) {
                $errors[] = [
                    'file'    => $file->getPathname(),
                    'message' => trim( $output ),
                ];
            }
        }

        return [
            'checked' => $checked,
            'errors'  => $errors,
        ];
    }

    private function get_recent_debug_log( $since_last = true ) {
        $log_file = WP_CONTENT_DIR . '/debug.log';

        if ( ! file_exists( $log_file ) ) {
            return [];
        }

        $size = filesize( $log_file );
        if ( $size === 0 ) {
            return [];
        }

        $max_read = 200 * 1024;
        $offset   = ( $size > $max_read ) ? $size - $max_read : 0;

        if ( $since_last ) {
            $last = (int) get_option( self::OPTION_LOG_MARKER, 0 );
            if ( $last > 0 && $last < $size ) {
                $offset = $last;
            }
        }

        $fh = fopen( $log_file, 'r' );
        if ( ! $fh ) {
            return [];
        }

        fseek( $fh, $offset );
        $data = '';
        while ( ! feof( $fh ) ) {
            $chunk = fread( $fh, 8192 );
            if ( $chunk === false ) {
                break;
            }
            $data .= $chunk;
        }
        fclose( $fh );

        update_option( self::OPTION_LOG_MARKER, $size, false );

        $lines = preg_split( '/\R/', $data );
        $lines = array_values( array_filter( array_map( 'trim', $lines ) ) );

        return $lines;
    }
}
