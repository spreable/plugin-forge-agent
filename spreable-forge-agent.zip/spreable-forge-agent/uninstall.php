<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

delete_option( 'spreable_forge_agent_token' );
delete_option( 'spreable_forge_last_log_marker' );
