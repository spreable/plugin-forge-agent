<?php
/**
 * Plugin Name: Spreable Forge Agent
 * Description: Agente interno para o Spreable Plugin Forge. Faz upload, instala, ativa e testa plugins gerados de forma automatizada.
 * Version: 1.0.0
 * Author: Spreable
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'SPREABLE_FORGE_AGENT_VERSION', '1.0.0' );
define( 'SPREABLE_FORGE_AGENT_DIR', plugin_dir_path( __FILE__ ) );
define( 'SPREABLE_FORGE_AGENT_BASENAME', plugin_basename( __FILE__ ) );

require_once SPREABLE_FORGE_AGENT_DIR . 'includes/class-spreable-forge-agent.php';

function spreable_forge_agent_init() {
    static $instance = null;

    if ( null === $instance ) {
        $instance = new Spreable_Forge_Agent();
    }

    return $instance;
}
add_action( 'plugins_loaded', 'spreable_forge_agent_init' );

function spreable_forge_agent_activate() {
    $agent = spreable_forge_agent_init();
    $agent::on_activation();
}
register_activation_hook( __FILE__, 'spreable_forge_agent_activate' );
